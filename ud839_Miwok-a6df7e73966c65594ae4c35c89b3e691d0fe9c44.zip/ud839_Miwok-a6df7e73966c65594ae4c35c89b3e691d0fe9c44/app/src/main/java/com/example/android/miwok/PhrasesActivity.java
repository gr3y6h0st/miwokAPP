package com.example.android.miwok;

import android.media.MediaPlayer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;
import java.util.ArrayList;

public class PhrasesActivity extends AppCompatActivity {
    private MediaPlayer mMediaPlayer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_phrases);

        //create ArrayList of phrases
        final ArrayList<Word> phrases = new ArrayList<Word>();

        phrases.add(new Word("Where are you goin?","minto wuksus"));
        phrases.add(new Word("What is your name?","tinne oyaasen'e"));
        phrases.add(new Word("My Name is...","oyaaset..."));
        phrases.add(new Word("How are you feeling","michekses?"));
        phrases.add(new Word("I'm feeling good.","kuchi achit"));
        phrases.add(new Word("Are you coming?","eenes'aa?"));
        phrases.add(new Word("Yes, I'm coming.","hee'eenem"));
        phrases.add(new Word("Let's go.","yoowutis"));
        phrases.add(new Word("Come here.","enii'nem"));

        WordAdapter adapter = new WordAdapter(this, phrases, R.color.category_phrases);

        ListView listView = (ListView) findViewById(R.id.phrasesListView);

        listView.setAdapter(adapter);
        }
}
