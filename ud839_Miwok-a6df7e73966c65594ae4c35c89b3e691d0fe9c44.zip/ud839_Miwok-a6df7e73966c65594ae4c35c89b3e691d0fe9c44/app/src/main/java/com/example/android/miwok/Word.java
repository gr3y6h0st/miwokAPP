package com.example.android.miwok;

import android.media.Image;
import android.widget.ImageView;

/** represents vocab word that user wants to learn. Contains default translate and Miwok Translation per word.
 * Created by jdifuntorum on 12/18/16.
 */

public class Word {

    /** Default English translation for the word */
    private String mEnglishTranslation;

    /**Default Miwok Translation for the word */
    private String mMiwokTranslation;

    /**Image associated with the current word*/
    private int mImageResourceID = NO_IMAGE_PROVIDED;

    /**Sound File associated with the current word*/
    private  int mSoundFile;

    /**Image resource ID*/
    private static final int NO_IMAGE_PROVIDED = -1;

    public Word(String englishTranslation, String miwokTranslation) {
        mEnglishTranslation = englishTranslation;
        mMiwokTranslation = miwokTranslation;
    }

    public Word(String englishTranslation, String miwokTranslation, int imageResourceID, int soundFile ) {
        mEnglishTranslation = englishTranslation;
        mMiwokTranslation = miwokTranslation;
        mImageResourceID = imageResourceID;
        mSoundFile = soundFile;
    }


    public String getEnglishTranslation(){
        return mEnglishTranslation;
    }

    public String getMiwokTranslation(){
        return mMiwokTranslation;
    }

    public int getImageResourceID(){
        return mImageResourceID;
    }

    public int getSoundFile(){
        return mSoundFile;
    }

    public boolean hasImage(){
        return mImageResourceID != NO_IMAGE_PROVIDED;
    }


}
